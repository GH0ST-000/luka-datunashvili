import java.sql.*;
import java.util.Scanner;

public class diagnosis {
    Connection conn1;
    Statement stObj;
    public diagnosis() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();
    }
    public void fetchDataforDiagnosis () throws Exception
    {
        String query = "select * from diagnosis";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Result : " + rs.getString("diagnosis2") +" "+ rs.getString("diagnosis3")+" "+
                    rs.getString("diagnosis4") );

        }

    }

}