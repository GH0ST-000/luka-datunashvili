package luka.datunashvili;

import java.sql.*;
import java.util.Scanner;

public class doctor {
    Connection conn1;
    Statement stObj;
    public doctor() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();
    }
    public void fetchDatafordoctor () throws Exception
    {
        String query = "select * from doctors";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Name : " + rs.getString("name"));

        }


    }
    public void fetchstatistic1 () throws Exception
    {
        String query = "select * from doctors where doctorID=6";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("სახელი : " + rs.getString("name")+" "+ "შეფასება 1-10 მდე : "+" "
                    + rs.getString("ball")+"100% "+" "+"პაციენტის მდგომარეობა:"+" "+ rs.getString("patient"));

        }


    }
    public void fetchstatistic2 () throws Exception
    {
        String query = "select * from doctors where doctorID=7";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("სახელი : " + rs.getString("name")+" "+ "შეფასება 1-10 მდე : "+" "
                    + rs.getString("ball")+" 90%"+" "+"პაციენტის მდგომარეობა:"+" "+ rs.getString("patient"));

        }


    }
    public void fetchstatistic3 () throws Exception
    {
        String query = "select * from doctors where doctorID=8";
       // String query1 = "select ball  from doctors where doctorID=8";

        ResultSet rs = stObj.executeQuery(query);
     //   ResultSet rs1 = stObj.executeQuery(query1);
       // int k=Integer.parseInt(String.valueOf(rs1));
        while (rs.next()) {
            System.out.println("სახელი : " + rs.getString("name")+" " +"შეფასება 1-10 მდე : "+" "
                    + rs.getString("ball")+" 70%"+" "+"პაციენტის მდგომარეობა:"+" "+ rs.getString("patient"));

        }


    }
}