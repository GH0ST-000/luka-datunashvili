package luka.datunashvili;

import java.sql.*;
import java.util.Scanner;

public class Database {
    Connection conn1;
    Statement stObj;
    public Database() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();
    }
    public void fetchData () throws Exception
    {
        String query = "select * from register";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Name : " + rs.getString("name")+" "+" "+"ID number : "+" "+" "+ rs.getString("innumber")+"Date Of Birth : "+" "+" "
                    + rs.getString("dateofbirth")+"Location : "+" "+" "
                    + rs.getString("location")+"Phone Number : "+" "+" "+ rs.getString("phonenumber")
                    +"Doctor Name : "+" " +" "+ rs.getString("luka.datunashvili.doctor")+"Symptom : "+" "+" "
                    + rs.getString("luka.datunashvili.symptom"));

        }
    }
    public void insertData(int idREGISTER, String name, String analysis,String medicament,String symptom) throws SQLException
    {
        if(idREGISTER!=0 &&  name!=null  && analysis!=null &&  medicament!=null && symptom !=null)
        {
            String query = "insert into patienthistory values( \""+idREGISTER+"\",\""+name+"\",\""+analysis+"\",\""+medicament+"\",\""+symptom+"\")";
            int a = stObj.executeUpdate(query);

            if(a == 1)
            {
                System.out.println("Registration Successfuly Done");
            }
            else
            {
                System.out.println("Registration Failed");
            }
        }
    }
    public void insertData1( int id,String simptomi) throws SQLException
    {
        if(simptomi!=null && id!=0)
        {
            String query1 = "insert into diagnosis values( \""+id+"\",\""+simptomi+"\")";
            int b = stObj.executeUpdate(query1);

            if(b == 1)
            {
                System.out.println(" ");
            }
            else
            {
                System.out.println("Registration Failed");
            }
        }
    }
    public void fetchData1 () throws Exception
    {
        String query = "select * from analysis WHERE  id =1";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Analysis : " + rs.getString("idanalysisans1")+" "+" "+"Another Analysis : "+" "+" "+ rs.getString("idanalysisans2"));

        }
    }
    public void fetchData2 () throws Exception
    {
        String query = "select * from medication WHERE  id =1";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Medicament : " + rs.getString("medication2")+" "+" "+"Another Medicament : "+" "+" "+ rs.getString("medication3"));

        }
    }
    public void insertData2(int id, String docname, int ball,String patient) throws SQLException
    {
        if(id!=0 &&  docname!=null  &&  ball!=0 &&   patient !=null)
        {
            String query = "insert into doctors values( \""+id+"\",\""+docname+"\",\""+ball+"\",\""+patient+"\")";
            int a = stObj.executeUpdate(query);

            if(a == 1)
            {
                System.out.println("შეფასება წარმატებით დასრულდა ");
            }
            else
            {
                System.out.println("Registration Failed");
            }
        }
    }










    public void takeDetails() throws SQLException {

    }


}
