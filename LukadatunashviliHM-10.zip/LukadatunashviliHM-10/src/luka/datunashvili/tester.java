package luka.datunashvili;

import java.sql.SQLException;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;

public class tester {
    public static Database d;
    public static Scanner sc;
    public static ExecutorService executorService;

    static
    {
        try{
            sc = new Scanner(System.in);
            d = new Database();
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    public static void main(String... q) throws SQLException, ClassNotFoundException, InterruptedException {
        Database mn = new Database();
        doctor doc = new doctor();
        symptom sym = new symptom();
        
        // boolean tasksEnded = executorService.awaitTermination(10, TimeUnit.SECONDS);
        // if (tasksEnded) {
        try {
            System.out.println("Enter your option");
            System.out.println("Analysis Result");
            System.out.println("1) View All Information");
            System.out.println("2) Registration Form");
            System.out.println("3) Doctor informtion");
            System.out.println("4) Symtom Information");
            int a = sc.nextInt();
            switch (a) {
                case 1:
                    mn.fetchData();
                    break;
                case 2:
                    System.out.println("Enter ID FOR REGISTRATION");
                    int idREGISTER = sc.nextInt();
                    System.out.println("Enter name");
                    String name = sc.next();
                    System.out.println("Enter IDnumber");
                    int innumber = sc.nextInt();
                    System.out.println("Enter DATE OF BIRTH");
                    int dateofbirth = sc.nextInt();
                    System.out.println("Enter LOCATION");
                    String location = sc.next();
                    System.out.println("Enter PHONE NUMBER");
                    int phonenumber = sc.nextInt();
                    System.out.println("Choose Doctor ");
                    doc.fetchDatafordoctor();
                    String doctor = sc.next();
                    System.out.println("Enter Your Symptom");
                    sym.fetchDataforsymptom();
                    String symptom = sc.next();
                  //  d.insertData(idREGISTER, name, innumber, dateofbirth, location, phonenumber, doctor, symptom);
                    break;
                case 3:
                    doc.fetchDatafordoctor();
                    break;
                case 4:
                    sym.fetchDataforsymptom();
                    break;
                case 5:
                    
                default:
                    System.out.print("Try Again");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        //     }
        //      else
        //    System.out.print("Error");


    }
}



