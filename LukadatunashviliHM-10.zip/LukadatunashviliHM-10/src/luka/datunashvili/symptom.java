package luka.datunashvili;

import java.sql.*;
import java.util.Scanner;

public class symptom {
    Connection conn1;
    Statement stObj;
    public symptom() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();/*Creating Statement Class's object which is responsible for performing all db tasks*/
    }
    public void fetchDataforsymptom () throws Exception
    {
        String query = "select * from symptom";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.print("Symptom : " + rs.getString("symptom2")+" "+ rs.getString("symptom3")+
                    " "+  rs.getString("symptom4")+" "+ rs.getString("symptom5")+" "+ rs.getString("symptom6"));

        }

    }

}