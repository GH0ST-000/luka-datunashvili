
import java.sql.*;
import java.util.Scanner;

public class meducant {
    Connection conn1;
    Statement stObj;
    public meducant() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();
    }
    public void fetchDataformedicant () throws Exception
    {
        String query = "select * from medication";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Result : " + rs.getString("medication2") +" "+ rs.getString("medication3")+" "+
                    rs.getString("medication4")+" "+  rs.getString("medication5")+" "+  rs.getString("medication6"));

        }

    }

}