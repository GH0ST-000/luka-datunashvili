
import java.sql.*;
import java.util.Scanner;

public class patienthistory {
    Connection conn1;
    Statement stObj;
    public patienthistory() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();
    }
    public void fetchDataforpatient () throws Exception
    {
        String query = "select * from patienthisstory";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Result : " + rs.getString("history2") +" "+ rs.getString("history3")+" "+
                    rs.getString("history4")+" "+  rs.getString("history5")+" "+  rs.getString("history6"));

        }

    }

}