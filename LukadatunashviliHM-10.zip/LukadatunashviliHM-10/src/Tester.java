import luka.datunashvili.symptom;
import luka.datunashvili.tester;
import luka.datunashvili.doctor;
import luka.datunashvili.Database;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;

public class Tester {
    public static Database d;
    public static Scanner sc;
    public static ExecutorService executorService;

    static
    {
        try{
            sc = new Scanner(System.in);
            d = new Database();
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }

    public static void main(String... q) throws SQLException, ClassNotFoundException, InterruptedException {
        Database mn = new Database();
        doctor doc = new doctor();
        symptom sym = new symptom();
        analysis an=new analysis();
        diagnosis da=new diagnosis();
        meducant md=new meducant();
        patienthistory ph=new patienthistory();
        // boolean tasksEnded = executorService.awaitTermination(10, TimeUnit.SECONDS);
        // if (tasksEnded) {
        try {
            System.out.println("Enter your option");
            System.out.println("1) View Statistic for Doctor");
            System.out.println("2) doctor visit");
            System.out.println("3) Doctor informtion");
            System.out.println("4) Symtom Information");
            System.out.println("5) Analysis Result");
            System.out.println("6) Diagnosis Result");
            System.out.println("7) Medicant");
            System.out.println("8) Hystory");
            System.out.println("9) Choose your symptom");
            System.out.println("9) Eqimis konsultacia");
            System.out.println("10) Eqimis Shefaseba");
            int a = sc.nextInt();
            switch (a) {
                case 1:
                   doc.fetchstatistic1();
                   doc.fetchstatistic2();
                   doc.fetchstatistic3();
                    break;
                case 2:
                    System.out.println("შეიყვანეთ ID");
                    int idREGISTER = sc.nextInt();
                    System.out.println("ექიმის კონსულტაცია");
                    doc.fetchDatafordoctor();
                    String name = sc.next();
                    System.out.println("ანალიზები");
                    an.fetchDataforanalysysr();
                    String analysis = sc.next();
                    System.out.println("მედიკამენტის დასახელება ");
                    md.fetchDataformedicant();
                    String medicament = sc.next();
                    System.out.println("Enter Your Symptom");
                    sym.fetchDataforsymptom();
                    String symptom = sc.next();
                    d.insertData(idREGISTER, name, analysis, medicament, symptom);
                    break;
                case 3:
                    doc.fetchDatafordoctor();
                    break;
                case 4:
                    sym.fetchDataforsymptom();
                    break;
                case 5:
                    an.fetchDataforanalysysr();
                    break;
                case 6:
                    da.fetchDataforDiagnosis();
                    break;
                case 7:
                    md.fetchDataformedicant();
                    break;
                case 8:
                    ph.fetchDataforpatient();
                    break;
                case 9:
                    System.out.println("შეიყვანეთ თქვენი ID");
                    int id = sc.nextInt();
                    System.out.println("შეიყვანეთ თქვენი სიმპტომი");
                    String symptomi = sc.next();
                    System.out.println("გთხოვთ დაელოდოთ ექიმის მითითებებს");
                    System.out.print("თქვენ უნად ჩაიტაროთ: "+" ");
                    d.fetchData1();
                    System.out.print("თქვენ უნად დალიოთ: "+" ");
                    d.fetchData2();
                    d.insertData1(id, symptomi);
                    break;
                case 10:
                    System.out.println("გთხოვთ შეიყვანოთ ID");
                    int id1 = sc.nextInt();
                    System.out.println("გთხოვთ შეიყვანოთ ექიმის სახელი რომელიც აირჩიეთ");
                    doc.fetchDatafordoctor();
                    String docname = sc.next();
                    System.out.println("მომსახურების ხარისი 1-10 ბალამდე");
                    int ball = sc.nextInt();
                    System.out.println("თქვენი მდგომარეობა ");
                    String patient = sc.next();
                    d.insertData2(id1, docname,ball,patient);
                    break;
                default:
                    System.out.print("Try Again");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        //     }
        //      else
        //    System.out.print("Error");


    }
}

