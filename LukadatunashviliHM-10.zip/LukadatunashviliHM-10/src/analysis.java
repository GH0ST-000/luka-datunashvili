

import java.sql.*;
import java.util.Scanner;

public class analysis {
    Connection conn1;
    Statement stObj;
    public analysis() throws SQLException, ClassNotFoundException {

        String url1 = "jdbc:mysql://localhost:3305/test";
        String user = "root";
        String password = "1qaz!QAZ";

        conn1 = DriverManager.getConnection(url1, user, password);

        stObj = conn1   .createStatement();
    }
    public void fetchDataforanalysysr () throws Exception
    {
        String query = "select * from analysis ";
        ResultSet rs = stObj.executeQuery(query);

        while (rs.next()) {
            System.out.println("Result : " + rs.getString("idanalysisans1") +" "+ rs.getString("idanalysisans2")+" "+
                    rs.getString("idanalysisans3") +" " + rs.getString("idanalysisans4"));

        }

    }

}
